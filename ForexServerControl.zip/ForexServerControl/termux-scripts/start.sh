#!/data/data/com.termux/files/usr/bin/bash
cd /data/data/com.termux/files/home/forex-server || exit 1

# Kill any existing instance first
pkill -f "uvicorn main:app" 2>/dev/null

# Start fresh in the background, logging output to server.log
nohup uvicorn main:app --host 0.0.0.0 --port 8000 > server.log 2>&1 &

termux-toast "Forex server started" 2>/dev/null
