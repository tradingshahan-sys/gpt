#!/data/data/com.termux/files/usr/bin/bash
pkill -f "uvicorn main:app"
termux-toast "Forex server stopped" 2>/dev/null
