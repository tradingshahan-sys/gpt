package com.example.forexserver

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    // Path to the scripts inside Termux's home directory.
    // These must exist and be executable (chmod +x) inside Termux.
    private val startScriptPath =
        "/data/data/com.termux/files/home/forex-server/start.sh"
    private val stopScriptPath =
        "/data/data/com.termux/files/home/forex-server/stop.sh"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val statusText = findViewById<TextView>(R.id.statusText)
        val startButton = findViewById<Button>(R.id.startButton)
        val stopButton = findViewById<Button>(R.id.stopButton)

        startButton.setOnClickListener {
            runTermuxScript(startScriptPath)
            statusText.text = "Sent: START"
            Toast.makeText(this, "Starting server...", Toast.LENGTH_SHORT).show()
        }

        stopButton.setOnClickListener {
            runTermuxScript(stopScriptPath)
            statusText.text = "Sent: STOP"
            Toast.makeText(this, "Stopping server...", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Sends a RUN_COMMAND intent to Termux, asking it to execute the given script.
     * Requires:
     *  1. Termux app installed
     *  2. "allow-external-apps=true" set in ~/.termux/termux.properties
     *  3. The script path must exist and be chmod +x inside Termux
     */
    private fun runTermuxScript(scriptPath: String) {
        try {
            val intent = Intent()
            intent.setClassName("com.termux", "com.termux.app.RunCommandService")
            intent.action = "com.termux.RUN_COMMAND"
            intent.putExtra("com.termux.RUN_COMMAND_PATH", scriptPath)
            intent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf<String>())
            intent.putExtra(
                "com.termux.RUN_COMMAND_WORKDIR",
                "/data/data/com.termux/files/home/forex-server"
            )
            intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
            ContextCompat.startForegroundService(this, intent)
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Error: ${e.message}\nIs Termux installed with allow-external-apps=true?",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
