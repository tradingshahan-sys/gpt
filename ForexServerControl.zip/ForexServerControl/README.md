# Forex Server Control — Android App (built without a computer)

ئەم ئەپە دوگمەی **Start Server** و **Stop Server**‌ی تێدایە.
کاتێک پێیان دەدەیت، فەرمان دەنێرێت بۆ Termux تاکو سێرڤەری forex-server هەڵبستێت/بوەستێنێت.

هەموو ئەم پرۆسەیە **بەبێ کۆمپیوتەر** ئەنجام دەدرێت — تەنها بە مۆبایل و هەژمارێکی GitHub.

---

## هەنگاوی ١: ڕاستکردنی Termux (لای سێرڤەرەکە)

لەناو Termux:

```bash
mkdir -p ~/.termux
echo "allow-external-apps=true" >> ~/.termux/termux.properties
termux-reload-settings
```

پاشان سکریپتەکانی `start.sh` و `stop.sh` (لەم پڕۆژەیەدا لە فۆڵدەری `termux-scripts/`) کۆپییان بکە بۆ ناو `~/forex-server/`:

```bash
cd ~/forex-server
nano start.sh
```
ناوەڕۆکی `termux-scripts/start.sh` بلکێنە، هەڵیبگرە.

```bash
nano stop.sh
```
ناوەڕۆکی `termux-scripts/stop.sh` بلکێنە، هەڵیبگرە.

دواتر بیانکە executable:
```bash
chmod +x start.sh stop.sh
```

پشکنینی دەستی (پێش ئەوەی بچیتە هەنگاوی داهاتوو، دڵنیابەرەوە کاردەکەن):
```bash
./start.sh
curl http://localhost:8000
./stop.sh
```

---

## هەنگاوی ٢: بارکردنی پڕۆژەکە بۆ GitHub (لە Termux، بەبێ کۆمپیوتەر)

1. ئەگەر هەژمارت لە GitHub نییە، لە مۆبایلەکەت بڕۆ بۆ https://github.com/signup و هەژمارێک دروست بکە.

2. **Personal Access Token** دروست بکە (بۆ push کردن پێویستە، نەک وشەی نهێنی):
   - بڕۆ بۆ: github.com → Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate new token
   - دەسەڵاتی `repo` هەڵبژێرە → Generate → **تۆکنەکە کۆپی بکە و هەڵیبگرە** (تەنها یەک جار پیشان دەدرێت)

3. لە github.com، ڕیپۆزیتۆرییەکی نوێ دروست بکە بە ناوی `forex-server-control` (public یان private، هەردووکیان کاردەکەن).

4. لە Termux:
```bash
pkg install git -y
cd ~
# فایلەکانی ئەم پرۆژەیە (ForexServerControl) بخە ناو ~/ForexServerControl
cd ~/ForexServerControl
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/USERNAME/forex-server-control.git
git push -u origin main
```
کاتێک داوای username/password کرد:
- **username**: ناوی هەژمارەکەت
- **password**: تۆکنەکەی هەنگاوی ٢ (نەک وشەی نهێنی ڕاستەقینەی هەژمارەکەت)

---

## هەنگاوی ٣: چاوەڕوانی build‌بوونی APK (خۆکارانە)

دوای push کردن، GitHub Actions خۆکارانە دەست بە build دەکات. لە مۆبایلەکەت:

1. بڕۆ بۆ ڕیپۆکەت لە github.com
2. کلیک لەسەر تابی **Actions**
3. run‌ی نوێترین ببینە (ناوی "Build APK") — چاوەڕێبە تا سەوز ببێت (٣-٥ خولەک دەخایەنێت)
4. کاتێک تەواو بوو، خۆرەوە بۆ خوارەوە بچۆ بۆ بەشی **Artifacts**
5. کلیک لەسەر `forex-server-control-apk` بکە بۆ داگرتنی فایلێکی zip

---

## هەنگاوی ٤: دامەزراندنی APK لەسەر مۆبایل

1. فایلی zip‌ی داگیراو بکەرەوە (بە هەر فایل مانەجەرێک) — APK‌یەک لەناوی دەبێت
2. یەکەم جار پێویستە ڕێگە بدەیت بە "دامەزراندنی ئەپ لە سەرچاوەی نەناسراو" بۆ Files/Chrome لە ڕێکخستنەکانی مۆبایل
3. کلیک لەسەر فایلی `.apk` بکە → Install

---

## هەنگاوی ٥: بەکارهێنان

1. ئەپی **Forex Server** بکەرەوە
2. کلیک لەسەر **Start Server** → داواکاری دەنێرێت بۆ Termux، سێرڤەرەکە هەڵدەستێت
3. کلیک لەسەر **Stop Server** بۆ ڕاگرتنی

> ⚠️ Termux پێویستە کراوە بێت (لانیکەم لە پشتەوە) بۆ ئەوەی فەرمانەکان وەریبگرێت. ئەگەر Termux بە تەواوی داخراوە (swiped away)، لەوانەیە فەرمانەکە کارنەکات — تکایە دڵنیابەرەوە Termux لە background‌دا ماوە.

---

## کێشە گونجاوەکان

- **"Error: ... Is Termux installed with allow-external-apps=true?"** → هەنگاوی ١ دووبارە بکەرەوە، دڵنیابەرەوە `termux-reload-settings` جێبەجێ کراوە.
- **Build لە GitHub Actions شکستی هێنا (سوور بوو)** → کلیک لەسەری بکە بۆ بینینی هەڵەکە، وێنە بنێرە بۆم تاکو یارمەتیت بدەم.
- **دوگمە کاردەناکات** → دڵنیابەرەوە Termux لە background‌دا کراوەیە و سکریپتەکان بە دروستی لە `~/forex-server/start.sh` و `stop.sh` دانراون و executable‌ن.
